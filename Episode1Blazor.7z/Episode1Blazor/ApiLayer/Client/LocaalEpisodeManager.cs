﻿namespace ApiLayer.Client
{
    internal class LocaalEpisodeManager
    {
    }
}