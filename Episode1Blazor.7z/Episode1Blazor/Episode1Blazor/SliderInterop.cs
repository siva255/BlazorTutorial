﻿namespace LearningProject
{
    internal class SliderInterop
    {
    }
}