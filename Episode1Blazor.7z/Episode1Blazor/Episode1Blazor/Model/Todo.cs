﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LearningProject.Model
{
    public class Todo
    {
        public string text { get; set; }
        public bool done { get; set; }
    }
}
